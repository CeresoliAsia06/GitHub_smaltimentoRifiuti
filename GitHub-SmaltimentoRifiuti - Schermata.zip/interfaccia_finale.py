from tkinter import scrolledtext
import tkinter as tk

from datetime import datetime

import Smalt_R1
import Smalt_R2
import Smalt_R3
import Smalt_R4
import Smalt_R5

import scorrimento

def oggetti_smaltiti():
    def leggi_file():
        bottone.config(state=tk.DISABLED)
        file_txt = "oggetti_smaltiti.txt"
        try:
            with open(file_txt, "r") as file:
                contenuto = file.read()
                areaTesto.insert(tk.END, contenuto)
                areaTesto.config(state=tk.DISABLED)
        except FileNotFoundError:
            areaTesto.insert(tk.END, "*** File non trovato ***\n", fg="red", font= ('calibri 12'),)
    
    
    def bottone_2():
        finestra.destroy()
        scelta_operazione()

    finestra = tk.Tk()
    finestra.title("Oggetti buttati")
    finestra.geometry("650x400")

    etichetta = tk.Label(finestra, text="Visualizza oggetti buttati", font= ('calibri 15 bold'))
    etichetta.grid(row=0, pady=20)

    areaTesto = scrolledtext.ScrolledText(finestra, width=60, height=15)
    areaTesto.grid()

    bottone = tk.Button(finestra, text="Visualizza", fg="blue", font= ('calibri 15 bold'), command=leggi_file)

    button2 = tk.Button(finestra, text="Torna al menu\nprincipale", fg="blue", font= ('calibri 15 bold'), command=bottone_2)

    bottone.grid(row=2, column=0, padx=10, pady=10)
    button2.grid(row=2, column=1, padx=10, pady=10)

    finestra.mainloop()

def oggetto_accettato(cat, lista):
    def bottone_premuto():
        finestra.destroy()
        leggi_peso(lista)

    finestra = tk.Tk()
    finestra.title("Oggetto accettato")
    finestra.geometry("500x150")

    etichetta = tk.Label(finestra, text=f"Oggetto accettato nella categoria {cat}", font=('calibri 15 bold'))
    etichetta.pack(pady=10)

    bottone=tk.Button(finestra, text="Continua", fg="blue", font= ('calibri 15 bold'), command=bottone_premuto)
    bottone.pack(pady=10)


def oggetto_riciclato():
    def bottone_premuto():
        finestra.destroy()
        scelta_operazione()

    finestra = tk.Tk()
    finestra.title("Oggetto riciclato")
    finestra.geometry("500x200")

    etichetta = tk.Label(finestra, text="*** Oggetto riciclato ***", font= ('calibri 16 bold'), fg="green")
    etichetta.pack(pady=20)

    bottone = tk.Button(finestra, text="Menu\nprincipale", fg="blue", font= ('calibri 15 bold'), command=bottone_premuto)
    bottone.pack(pady=10)

    finestra.mainloop()

def peso_accettato():
    def bottone_premuto():
        finestra.destroy()
        oggetto_riciclato()

    finestra = tk.Tk()
    finestra.title("Categoria accettata")
    finestra.geometry("500x120")

    etichetta = tk.Label(finestra, text="*** Oggetto accettato ***",fg="red", font= ('calibri 16 bold'))
    etichetta.pack(pady=20)

    bottone = tk.Button(finestra, text="Continua", fg="blue", font= ('calibri 15 bold'), command=bottone_premuto)
    bottone.pack(pady=10)

    finestra.mainloop()

def oggetto_non_trovato():
    def bottone_premuto():
        finestra.destroy()
        scelta_operazione()

    finestra = tk.Tk()
    finestra.title("Categoria non trovato")
    finestra.geometry("500x130")

    etichetta = tk.Label(finestra, text="*** Oggetto non presente nelle categorie ***", font= ('calibri 16 bold'), fg="red")
    etichetta.pack(pady=20)

    bottone = tk.Button(finestra, text="Continua", fg="blue", font= ('calibri 15 bold'), command=bottone_premuto)
    bottone.pack(pady=10)

    finestra.mainloop()


def oggetto_non_presente(cat):

    def leggi_file(cat):
        bottone.config(state=tk.DISABLED)
        file_txt = cat 
        try:
            with open(file_txt, "r") as file:
                contenuto = file.read()
                areaTesto.insert(tk.END, contenuto)
                areaTesto.config(state=tk.DISABLED)
        except FileNotFoundError:
            areaTesto.insert(tk.END, "*** File non trovato ***\n", fg="red", font= ('calibri 16 bold'))

    def bottone_1(cat):
        leggi_file(cat)
    def bottone_2():
        finestra.destroy()
        so_smaltire()
    def bottone_3():
        finestra.destroy()
        non_so_smaltire()

    finestra = tk.Tk()
    finestra.title("Elenco categoria inserita")
    finestra.geometry("600x400")

    etichetta = tk.Label(finestra, text="Elenco della categoria selezionata", font= ('calibri 12'))
    etichetta.grid(row=0, pady=20)

    areaTesto = scrolledtext.ScrolledText(finestra, width=50, height=15)
    areaTesto.grid()

    bottone = tk.Button(finestra, text="Leggi file", fg="blue", font= ('calibri 12'), command=lambda: bottone_1(cat))
    button2 = tk.Button(finestra, text="Inserisci nuovo\noggetto", fg="blue", font= ('calibri 12'), command=bottone_2)
    button3 = tk.Button(finestra, text="Continua in\n- non so smaltire", fg="blue", font= ('calibri 12'), command=bottone_3)

    bottone.grid(row=2, column=0, padx=10, pady=10)
    button2.grid(row=1, column=1, padx=10, pady=10)
    button3.grid(row=2, column=1, padx=10, pady=10)

    finestra.mainloop()

def errore_funz(val):
    def bottone_premuto(val):
        finestra.destroy()
        oggetto_non_presente(val)
    
    finestra=tk.Tk()
    finestra.title="Messaggio errore"
    finestra.geometry("600x150")

    etichetta= tk.Label(finestra, text="*** Oggetto inserito non presente nella categoria selezionata ***", font=('calibri 16 bold'), fg="red")
    etichetta.pack(pady=10)

    bottone= tk.Button(finestra, text="Continua", fg="blue", font=('calibri 15 bold'), command=lambda:bottone_premuto(val))
    bottone.pack(pady=10)

    finestra.mainloop()

def leggi_peso(lista):
    def bottone_premuto(lista):
        input_text = ogg.get()
        error = 0
        try:
            peso=float(input_text)
        except:
            error = 1
            errore.config(text="Inserisci un numero decimale (kg)", fg="red", font=('calibri 15 bold'))
        if error != 1:
            fileWrite = open('Oggetti_smaltiti.txt', 'a')
            oggetto_salvato.set(input_text)
            lista.append(peso)
            fileWrite.write(f"""\nData: {lista[0]}
    Oggetto: {lista[1]}
    Categoria: {lista[2]}
    Peso: {lista[3]}kg\n""")
            
            fileWrite.close()
            
            etichetta.config(text="Oggetto inserito correttamente", font= ('calibri 12'))
            etichetta.after(200, finestra.destroy)
            peso_accettato()

    finestra = tk.Tk()
    finestra.title("Peso")
    finestra.geometry("400x250")

    etichetta = tk.Label(finestra, text="Inserisci il peso dell'oggetto da smaltire (kg):", font= ('calibri 12'))
    etichetta.pack(pady=10)

    ogg = tk.Entry(finestra)
    ogg.pack(pady=20, padx=10)

    bottone = tk.Button(finestra, text="INVIA", fg="blue", font= ('calibri 15 bold'), command=lambda: bottone_premuto(lista))
    bottone.pack(pady=10)

    oggetto_salvato = tk.StringVar()
    output_label = tk.Label(finestra, text="Oggetto Inserito Correttamente!", font= ('calibri 12'),)

    errore = tk.Label(finestra, text="Compila", font= ('calibri 15 bold'))
    errore.pack()

    finestra.mainloop()

    if oggetto_salvato.get():
        print("Valore salvato: ", oggetto_salvato.get())
        return oggetto_salvato.get()



def oggetto_presente(stringa, lista):
    def bottone_premuto():
        finestra.destroy()
        leggi_peso(lista)

    finestra = tk.Tk()
    finestra.title("Categoria accettata")
    finestra.geometry("500x120")

    etichetta = tk.Label(finestra, text=stringa.capitalize(), font= ('calibri 15 bold'))
    etichetta.pack(pady=20)

    bottone = tk.Button(finestra, text="Continua", fg="blue", font= ('calibri 15 bold'), command=bottone_premuto)
    bottone.pack(pady=10)

    finestra.mainloop()

def non_so_smaltire():
    def bottone_premuto():
            input_text = ogg.get()
            if input_text:
                oggetto_salvato.set(input_text)
                finestra.destroy()
            else:
                errore.config(text="Compila", fg="red", font= ('calibri 16 bold'))

    finestra = tk.Tk()
    finestra.title("Differenzia rifiuto")
    finestra.geometry("300x250")

    etichetta = tk.Label(finestra, text="Inserisci l'oggetto da smaltire:",font= ('calibri 12 bold'),)
    etichetta.pack(pady=10)

    ogg = tk.Entry(finestra)
    ogg.pack(pady=20, padx=10)

    bottone = tk.Button(finestra, text="INVIA", fg="blue", font= ('calibri 15 bold'), command=bottone_premuto)
    bottone.pack(pady=10)

    oggetto_salvato = tk.StringVar()
    output_label = tk.Label(finestra, textvariable=oggetto_salvato)
    output_label.pack()

    errore = tk.Label(finestra, text="Compila", font= ('calibri 16 bold'))
    errore.pack()

    finestra.mainloop()

    if oggetto_salvato.get():
        print("Oggetto salvato: ", oggetto_salvato.get().capitalize())
        og_salvato = oggetto_salvato.get().capitalize()
        oggetto, categoria = scorrimento.main(og_salvato)
        if oggetto == "Oggetto non trovato" and categoria == None:
            oggetto_non_trovato()
        else:
            if categoria == "R1":
                data = datetime.today()
                lista= [data, oggetto, categoria]
                oggetto_accettato(categoria,lista)
            elif categoria == "R2":
                data = datetime.today()
                lista= [data, oggetto, categoria]
                oggetto_accettato(categoria,lista)
            elif categoria == "R3":
                data = datetime.today()
                lista= [data, oggetto, categoria]
                oggetto_accettato(categoria,lista)
            elif categoria == "R4":
                data = datetime.today()
                lista= [data, oggetto, categoria]
                oggetto_accettato(categoria,lista)
            elif categoria == "R5":
                data = datetime.today()
                lista= [data, oggetto, categoria]
                oggetto_accettato(categoria,lista)
              
def so_smaltire():
    fileWrite = open("Oggetti_smaltiti.txt", "a")
    def bottone_premuto():
        input_text = ogg.get()

        if input_text != "" and opzioni_val != "":
            oggetto_salvato.set(input_text)
            opzione_salvata.set(opzioni_val.get())
            if opzioni_val.get() == "R1":
                if Smalt_R1.R1(input_text):
                    finestra.destroy()
                    data = datetime.today()
                    lista = [data, input_text.capitalize(), opzioni_val.get()]
                    oggetto_presente(input_text, lista)
                else:
                    finestra.destroy()
                    errore_funz("r1.txt")
                
            elif opzioni_val.get() == "R2":
                if Smalt_R2.R2(input_text):
                    finestra.destroy()
                    data = datetime.today()
                    lista = [data, input_text.capitalize(), opzioni_val.get()]
                    oggetto_presente(input_text, lista)
                else:
                    finestra.destroy()
                    errore_funz("r2.txt")
            elif opzioni_val.get() == "R3":
                if Smalt_R3.R3(input_text):
                    finestra.destroy()
                    data = datetime.today()
                    lista = [data, input_text.capitalize(), opzioni_val.get()]
                    oggetto_presente(input_text, lista)
                else:
                    finestra.destroy()
                    errore_funz("r3.txt")
            elif opzioni_val.get() == "R4":
                if Smalt_R4.R4(input_text):
                    finestra.destroy()
                    data = datetime.today()
                    lista = [data, input_text.capitalize(), opzioni_val.get()]
                    oggetto_presente(input_text, lista)
                else:
                    finestra.destroy()
                    errore_funz("r4.txt")
            elif opzioni_val.get() == "R5":
                if Smalt_R5.R5(input_text):
                    finestra.destroy()
                    data = datetime.today()
                    lista = [data, input_text.capitalize(), opzioni_val.get()]
                    oggetto_presente(input_text, lista)
                else:
                    finestra.destroy()
                    errore_funz("r5.txt")
                
        else:
            errore.config(text="Compila tutti i campi!", font= ('calibri 16'))
        fileWrite.close()

    def scegli_opzione(*args):
        selezione = opzioni_val.get()
        description_label.config(text=descrizioni[selezione])


    finestra = tk.Tk()
    finestra.title("Differenzia rifiuto")
    finestra.geometry("500x450")

    menu_etichetta = tk.Label(finestra, text="\n\nSeleziona una opzione:", font= ('calibri 16 bold'))
    menu_etichetta.pack()

    opzioni_val = tk.StringVar(finestra)
    opzioni_val.set("")

    descrizioni = {
        "R1": "Grande bianco freddo\ngrandi elettrodomestici per la refrigerazione: frigoriferi, congelatori, condizionatori",
        "R2": "Grande bianco non freddo\ngrandi elettrodomestici come lavatrici, lavastoviglie",
        "R3": "TV Monitor a tubo catodico",
        "R4": "Elettronica di consumo, Telecomunicazioni, Informatica, piccoli elettrodomestici,\nelettroutensili, giocattoli, apparecchi di illuminazione, dispositivi medici",
        "R5": "Sorgenti luminose a scarica: lampade fluorescenti e sorgenti luminose compatte"
    }

    menu = tk.OptionMenu(finestra, opzioni_val, *descrizioni.keys(), command=scegli_opzione)
    menu.pack()

    #descrizione
    description_label = tk.Label(finestra, text="")
    description_label.pack(pady=10)

    ogg_etichetta = tk.Label(finestra, text="Inserisci l'oggetto:", font= ('calibri 12 bold'),)
    ogg_etichetta.pack(pady=10)

    ogg = tk.Entry(finestra)
    ogg.pack()

    bottone = tk.Button(finestra, text="FINE", fg="blue", font= ('calibri 12 bold'), command=bottone_premuto)
    bottone.pack(pady=10)


    oggetto_salvato = tk.StringVar()
    output_label = tk.Label(finestra, textvariable=oggetto_salvato)
    output_label.pack()

    opzione_salvata = tk.StringVar()
    option_label = tk.Label(finestra, textvariable=opzione_salvata)
    option_label.pack()

    errore = tk.Label(finestra, text="Compila tutti i campi!", fg="red", font= ('calibri 16 bold'))
    errore.pack()

    finestra.mainloop()

    if oggetto_salvato.get() and opzione_salvata.get():
        print("Valore salvato: ", oggetto_salvato.get().capitalize())
        print("Opzione salvata: ", opzione_salvata.get())
    else:
        print("Compila tutti i campi prima di inviare i dati.")

def scelta_1():
    finestra = tk.Tk()
    finestra.title("Smaltire")

    ogg_etichetta = tk.Label(finestra, text="Sai dove smaltire?", font= ('calibri 16 bold'),)
    ogg_etichetta.grid(row=0, column=0, padx=10, pady=10)

    def buttone_1():
        finestra.destroy()
        so_smaltire()
        return("Y")

    def buttone_2():
        finestra.destroy()
        non_so_smaltire()
        return("N")

    button1 = tk.Button(finestra, text="So dove si\nsmaltisce", font= ('calibri 12'), command=buttone_1)
    button2 = tk.Button(finestra, text="Non so dove si\nsmaltisce",font= ('calibri 12'), command=buttone_2)

    button1.grid(row=1, column=0, padx=10, pady=10)
    button2.grid(row=1, column=1, padx=10, pady=10)

    finestra.mainloop()

def scelta_operazione():
    finestra = tk.Tk()
    finestra.title("Operazione")
    finestra.geometry()

    ogg_etichetta = tk.Label(finestra, text="Scegli operazione:\n", font=('calibri 16 bold'))
    ogg_etichetta.grid(row=0, column=1, padx=10, pady=10)

    def buttone_1():
        finestra.destroy()
        scelta_1()
        return(1)

    def buttone_2():
        print("pulsante 2")
        finestra.destroy()
        oggetti_smaltiti()
        return(2)

    def buttone_3():
        print("pulsante 3")
        finestra.destroy()
        return(3)

    button1 = tk.Button(finestra, text="Smaltisci\nrifiuto", font= ('calibri 12'),command=buttone_1)
    button2 = tk.Button(finestra, text="Visualizza\noggetti\nbuttati", font= ('calibri 12'), command=buttone_2)
    button3 = tk.Button(finestra, text="Esci", fg="blue", font= ('calibri 15 bold'), command=buttone_3)

    button1.grid(row=1, column=0, padx=10, pady=10)
    button2.grid(row=1, column=1, padx=10, pady=10)
    button3.grid(row=1, column=2, padx=10, pady=10)

    finestra.mainloop()

#############################################  PROGRAMMA PRINCIPALE  #############################################
scelta_operazione()